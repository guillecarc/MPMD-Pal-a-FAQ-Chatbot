## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_6: contact
* master_contact
    - utter_master_contact

## story_17: starting_date
* master_start
    - utter_master_start

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_14: program_content
* master_program_content
    - utter_master_program_content

## story_5: career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_15: scholarships
* master_scholarships
    - utter_master_scholarships

## story_9: electives
* master_electives
    - utter_master_electives

## story_10: further_qualification
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_29: greet + program_content + semester_content + electives + start
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_26: tuition_fees + scholarships + starting_date + bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_15: scholarships
* master_career_opportunities
    - utter_master_career_opportunities
* master_scholarships
    - utter_master_scholarships
* master_scholarships
    - utter_master_scholarships

## story_14: program_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_program_content
    - utter_master_program_content

## story_22: degree + application_period + duration + location + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_14: program_content
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_program_content
    - utter_master_program_content

## story_15: scholarships
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_scholarships
    - utter_master_scholarships

## story_20: greet + program_content + language + thank + good_deny + bye
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content

## story_26: tuition_fees + scholarships + starting_date + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_program_content
    - utter_master_program_content
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_5: career_opportunities
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_17: starting_date
* master_career_opportunities
    - utter_master_career_opportunities
* master_start
    - utter_master_start

## story_14: program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_16: semester_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_14: program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_program_content
    - utter_master_program_content

## story_15: scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_scholarships
    - utter_master_scholarships

## story_14: program_content
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_15: scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_scholarships
    - utter_master_scholarships

## story_6: contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_18: tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_electives
    - utter_master_electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_5: career_opportunities
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_career_opportunities
    - utter_master_career_opportunities

## story_10: further_qualification
* master_career_opportunities
    - utter_master_career_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_4: application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_scholarships
    - utter_master_scholarships
* master_application_period
    - utter_master_application_period

## story_14: program_content
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content

## story_18: tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_scholarships
    - utter_master_scholarships

## story_4: application_period
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_9: electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_electives
    - utter_master_electives

## story_4: application_period
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_15: scholarships
* master_program_content
    - utter_master_program_content
* master_scholarships
    - utter_master_scholarships

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees

## story_15: scholarships
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships

## Generated Story -3593820311814593027
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_start
    - utter_master_start
* master_application_period
    - utter_master_application_period

## story_16: semester_content
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_20: greet + program_content + language + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact

## story_9: electives
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_20: greet + program_content + language + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_5: career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_career_opportunities
    - utter_master_career_opportunities

## story_4: application_period
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_16: semester_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_5: career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_9: electives
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_6: contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact

## story_17: starting_date
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_5: career_opportunities
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities

## story_5: career_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities

## story_17: starting_date
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_start
    - utter_master_start

## story_6: contact
* master_scholarships
    - utter_master_scholarships
* master_electives
    - utter_master_electives
* master_contact
    - utter_master_contact

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_15: scholarships
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_scholarships
    - utter_master_scholarships

## story_26: tuition_fees + scholarships + starting_date + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_scholarships
    - utter_master_scholarships
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_14: program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_application_period
    - utter_master_application_period

## story_6: contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact

## story_5: career_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_application_period
    - utter_master_application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_6: contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_15: scholarships
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_scholarships
    - utter_master_scholarships

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_16: semester_content
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_scholarships
    - utter_master_scholarships

## story_14: program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_program_content
    - utter_master_program_content

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start

## story_10: further_qualification
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_16: semester_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_29: greet + program_content + semester_content + electives + start
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships

## story_10: further_qualification
* master_career_opportunities
    - utter_master_career_opportunities
* master_scholarships
    - utter_master_scholarships
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_9: electives
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact
* master_electives
    - utter_master_electives

## story_16: semester_content
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_20: greet + program_content + language + thank + good_deny + bye
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_electives
    - utter_master_electives
* master_electives
    - utter_master_electives

## story_26: tuition_fees + scholarships + starting_date + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_5: career_opportunities
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_career_opportunities
    - utter_master_career_opportunities

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_tuition_fees
    - utter_master_tuition_fees

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_17: starting_date
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start

## story_16: semester_content
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_contact
    - utter_master_contact

## story_10: further_qualification
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_9: electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_22: degree + application_period + duration + location + bye
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start

## story_5: career_opportunities
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_career_opportunities
    - utter_master_career_opportunities

## story_18: tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_9: electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_electives
    - utter_master_electives

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_tuition_fees
    - utter_master_tuition_fees

## story_5: career_opportunities
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_career_opportunities
    - utter_master_career_opportunities

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start

## story_15: scholarships
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_scholarships
    - utter_master_scholarships

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_29: greet + program_content + semester_content + electives + start
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_career_opportunities
    - utter_master_career_opportunities

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_9: electives
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_scholarships
    - utter_master_scholarships
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_26: tuition_fees + scholarships + starting_date + bye
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_16: semester_content
* master_electives
    - utter_master_electives
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_16: semester_content
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_26: tuition_fees + scholarships + starting_date + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_career_opportunities
    - utter_master_career_opportunities
* master_tuition_fees
    - utter_master_tuition_fees

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_tuition_fees
    - utter_master_tuition_fees

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_17: starting_date
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start

## story_17: starting_date
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_start
    - utter_master_start

## story_20: greet + program_content + language + thank + good_deny + bye
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* master_scholarships
    - utter_master_scholarships

## story_22: degree + application_period + duration + location + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start

## story_17: starting_date
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start

## story_18: tuition_fees
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees

## story_20: greet + program_content + language + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_scholarships
    - utter_master_scholarships
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_17: starting_date
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_start
    - utter_master_start

## story_9: electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_electives
    - utter_master_electives

## story_17: starting_date
* master_program_content
    - utter_master_program_content
* master_start
    - utter_master_start

## story_4: application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_9: electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_electives
    - utter_master_electives

## story_17: starting_date
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_15: scholarships
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_scholarships
    - utter_master_scholarships

## story_15: scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_scholarships
    - utter_master_scholarships

## story_22: degree + application_period + duration + location + bye
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_4: application_period
* master_scholarships
    - utter_master_scholarships
* master_electives
    - utter_master_electives
* master_application_period
    - utter_master_application_period

## story_6: contact
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact

## story_26: tuition_fees + scholarships + starting_date + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_17: starting_date
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start

## story_26: tuition_fees + scholarships + starting_date + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_14: program_content
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content

