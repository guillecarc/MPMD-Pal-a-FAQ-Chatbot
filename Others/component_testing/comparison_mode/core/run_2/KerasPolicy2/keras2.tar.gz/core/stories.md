## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_19: thank
* thank
    - utter_thank

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* greet
    - utter_greet

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_7: degree
* master_degree
    - utter_master_degree

## story_11: how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_1: bye
* bye
    - utter_bye

## story_13: location
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_5: career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* master_contact
    - utter_master_contact

## story_12: language
* master_language
    - utter_master_language

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_13: location
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* master_location
    - utter_master_location

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_1: bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_13: location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location

## story_18: tuition_fees
* thank
    - utter_thank
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees

## story_13: location
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_13: location
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_language
    - utter_master_language

## story_18: tuition_fees
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_3: admission_requirements
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_6: contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_contact
    - utter_master_contact

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet

## story_16: semester_content
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_19: thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* thank
    - utter_thank

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_19: thank
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_19: thank
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* thank
    - utter_thank

## story_12: language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_11: how_to_apply
* master_tuition_fees
    - utter_master_tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_application_period
    - utter_master_application_period

## story_12: language
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_1: bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_6: contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_5: career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_4: application_period
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_1: bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_7: degree
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree

## story_1: bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_2: greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet

## story_7: degree
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_contact
    - utter_master_contact

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_1: bye
* thank
    - utter_thank
* bye
    - utter_bye

## story_5: career_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_career_opportunities
    - utter_master_career_opportunities

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_19: thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* thank
    - utter_thank

## story_16: semester_content
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_10: further_qualification
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language

## story_11: how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply

## story_18: tuition_fees
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_tuition_fees
    - utter_master_tuition_fees

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_19: thank
* master_degree
    - utter_master_degree
* thank
    - utter_thank

## story_2: greet
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* greet
    - utter_greet

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_application_period
    - utter_master_application_period

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_16: semester_content
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_13: location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_career_opportunities
    - utter_master_career_opportunities

## story_7: degree
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree

## story_4: application_period
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_career_opportunities
    - utter_master_career_opportunities

## story_11: how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_6: contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_4: application_period
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_3: admission_requirements
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_19: thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_16: semester_content
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_20: greet + program_content + language + thank + good_deny + bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_5: career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_career_opportunities
    - utter_master_career_opportunities

## story_6: contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact

## story_20: greet + program_content + language + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_language
    - utter_master_language

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_5: career_opportunities
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank
* master_career_opportunities
    - utter_master_career_opportunities

## story_2: greet
* thank
    - utter_thank
* greet
    - utter_greet

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_1: bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_19: thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank

## story_16: semester_content
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_3: admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_admission_requirements
    - utter_master_admission_requirements

## story_2: greet
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* greet
    - utter_greet

## story_10: further_qualification
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_5: career_opportunities
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_5: career_opportunities
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_11: how_to_apply
* thank
    - utter_thank
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_5: career_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_11: how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_13: location
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location

## story_6: contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_contact
    - utter_master_contact

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_16: semester_content
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply

## story_10: further_qualification
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_18: tuition_fees
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_1: bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* bye
    - utter_bye

## story_3: admission_requirements
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements

## story_1: bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* bye
    - utter_bye

## story_1: bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_6: contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact

## story_16: semester_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_18: tuition_fees
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language

## story_2: greet
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_29: greet + program_content + semester_content + electives + start
* master_admission_requirements
    - utter_master_admission_requirements
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_7: degree
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree

## story_18: tuition_fees
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_3: admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_admission_requirements
    - utter_master_admission_requirements

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact

## story_19: thank
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* master_career_opportunities
    - utter_master_career_opportunities
* greet
    - utter_greet

## story_13: location
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements
* master_contact
    - utter_master_contact

## story_19: thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* thank
    - utter_thank

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_tuition_fees
    - utter_master_tuition_fees

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_7: degree
* thank
    - utter_thank
* master_degree
    - utter_master_degree

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_16: semester_content
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_13: location
* master_tuition_fees
    - utter_master_tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_5: career_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_2: greet
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_20: greet + program_content + language + thank + good_deny + bye
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_7: degree
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_19: thank
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_career_opportunities
    - utter_master_career_opportunities

## story_18: tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* master_application_period
    - utter_master_application_period

## story_6: contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_3: admission_requirements
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

