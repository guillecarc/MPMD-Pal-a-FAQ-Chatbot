## story_2: greet
* greet
    - utter_greet

## story_13: location
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_contact
    - utter_master_contact

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_7: degree
* master_degree
    - utter_master_degree

## story_19: thank
* thank
    - utter_thank

## story_9: electives
* master_electives
    - utter_master_electives

## story_1: bye
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_12: language
* master_language
    - utter_master_language

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_13: location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_20: greet + program_content + language + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_3: admission_requirements
* greet
    - utter_greet
* thank
    - utter_thank
* master_admission_requirements
    - utter_master_admission_requirements

## story_1: bye
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* bye
    - utter_bye

## story_4: application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_20: greet + program_content + language + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* thank
    - utter_thank
* master_language
    - utter_master_language

## story_2: greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* greet
    - utter_greet

## story_29: greet + program_content + semester_content + electives + start
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_26: tuition_fees + scholarships + starting_date + bye
* greet
    - utter_greet
* thank
    - utter_thank
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_26: tuition_fees + scholarships + starting_date + bye
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_9: electives
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* master_electives
    - utter_master_electives

## story_6: contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* master_contact
    - utter_master_contact

## story_7: degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* thank
    - utter_thank

## story_4: application_period
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_3: admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_admission_requirements
    - utter_master_admission_requirements

## story_3: admission_requirements
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_electives
    - utter_master_electives

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* thank
    - utter_thank
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_electives
    - utter_master_electives

## story_19: thank
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* thank
    - utter_thank

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_2: greet
* greet
    - utter_greet
* greet
    - utter_greet

## story_7: degree
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_degree
    - utter_master_degree

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_2: greet
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* greet
    - utter_greet

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_3: admission_requirements
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_22: degree + application_period + duration + location + bye
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_application_period
    - utter_master_application_period

## story_13: location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_5: career_opportunities
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_5: career_opportunities
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_6: contact
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_contact
    - utter_master_contact

## story_10: further_qualification
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_19: thank
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_19: thank
* greet
    - utter_greet
* thank
    - utter_thank
* thank
    - utter_thank

## story_2: greet
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_12: language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_7: degree
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_19: thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location
* thank
    - utter_thank

## story_26: tuition_fees + scholarships + starting_date + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_19: thank
* master_admission_requirements
    - utter_master_admission_requirements
* thank
    - utter_thank

## story_20: greet + program_content + language + thank + good_deny + bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_4: application_period
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_26: tuition_fees + scholarships + starting_date + bye
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_9: electives
* master_admission_requirements
    - utter_master_admission_requirements
* master_electives
    - utter_master_electives

## story_18: tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_13: location
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_10: further_qualification
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_career_opportunities
    - utter_master_career_opportunities
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_career_opportunities
    - utter_master_career_opportunities
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_10: further_qualification
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_12: language
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language

## story_19: thank
* master_language
    - utter_master_language
* thank
    - utter_thank

## story_19: thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_6: contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_contact
    - utter_master_contact

## story_18: tuition_fees
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* bye
    - utter_bye

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_1: bye
* bye
    - utter_bye
* bye
    - utter_bye

## story_5: career_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_7: degree
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_20: greet + program_content + language + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_3: admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements

## story_20: greet + program_content + language + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_13: location
* greet
    - utter_greet
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_admission_requirements
    - utter_master_admission_requirements

## story_7: degree
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree

## story_22: degree + application_period + duration + location + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_7: degree
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_degree
    - utter_master_degree

## story_3: admission_requirements
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_3: admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements

## story_3: admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_admission_requirements
    - utter_master_admission_requirements

## story_1: bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_4: application_period
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_9: electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_electives
    - utter_master_electives

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_29: greet + program_content + semester_content + electives + start
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact

## story_12: language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_language
    - utter_master_language

## story_13: location
* master_career_opportunities
    - utter_master_career_opportunities
* master_location
    - utter_master_location

## story_20: greet + program_content + language + thank + good_deny + bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_5: career_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_career_opportunities
    - utter_master_career_opportunities

## story_13: location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_26: tuition_fees + scholarships + starting_date + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_13: location
* master_location
    - utter_master_location
* master_location
    - utter_master_location

## story_2: greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* greet
    - utter_greet

## story_5: career_opportunities
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_career_opportunities
    - utter_master_career_opportunities

## story_1: bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* bye
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language

## story_2: greet
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* greet
    - utter_greet

## story_26: tuition_fees + scholarships + starting_date + bye
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location

## story_29: greet + program_content + semester_content + electives + start
* master_admission_requirements
    - utter_master_admission_requirements
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_6: contact
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_6: contact
* master_location
    - utter_master_location
* master_contact
    - utter_master_contact

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_20: greet + program_content + language + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_7: degree
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period

## story_5: career_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact
* master_career_opportunities
    - utter_master_career_opportunities

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_20: greet + program_content + language + thank + good_deny + bye
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_2: greet
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet

## story_3: admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_5: career_opportunities
* thank
    - utter_thank
* master_career_opportunities
    - utter_master_career_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_3: admission_requirements
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_3: admission_requirements
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_10: further_qualification
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_5: career_opportunities
* greet
    - utter_greet
* thank
    - utter_thank
* master_career_opportunities
    - utter_master_career_opportunities

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_19: thank
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* thank
    - utter_thank

## story_10: further_qualification
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_6: contact
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact

## story_2: greet
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet

## story_19: thank
* thank
    - utter_thank
* thank
    - utter_thank

## story_19: thank
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* thank
    - utter_thank

## story_20: greet + program_content + language + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_2: greet
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet

## story_13: location
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_5: career_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_career_opportunities
    - utter_master_career_opportunities

## story_9: electives
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_electives
    - utter_master_electives

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* master_location
    - utter_master_location
* greet
    - utter_greet

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_career_opportunities
    - utter_master_career_opportunities
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_2: greet
* bye
    - utter_bye
* greet
    - utter_greet

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_9: electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_29: greet + program_content + semester_content + electives + start
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_7: degree
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location

## story_29: greet + program_content + semester_content + electives + start
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_contact
    - utter_master_contact

## story_10: further_qualification
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

