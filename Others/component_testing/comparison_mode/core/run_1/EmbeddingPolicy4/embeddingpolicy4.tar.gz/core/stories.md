## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_12: language
* master_language
    - utter_master_language

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_4: application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_application_period
    - utter_master_application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period
* master_language
    - utter_master_language

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_26: tuition_fees + scholarships + starting_date + bye
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_12: language
* master_application_period
    - utter_master_application_period
* master_language
    - utter_master_language

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_4: application_period
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_12: language
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_language
    - utter_master_language

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_4: application_period
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_16: semester_content
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_26: tuition_fees + scholarships + starting_date + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

## story_12: language
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_language
    - utter_master_language

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_12: language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_12: language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_26: tuition_fees + scholarships + starting_date + bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_16: semester_content
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_26: tuition_fees + scholarships + starting_date + bye
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_16: semester_content
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_16: semester_content
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_application_period
    - utter_master_application_period

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_12: language
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees

## story_18: tuition_fees
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees

## story_26: tuition_fees + scholarships + starting_date + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_4: application_period
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

