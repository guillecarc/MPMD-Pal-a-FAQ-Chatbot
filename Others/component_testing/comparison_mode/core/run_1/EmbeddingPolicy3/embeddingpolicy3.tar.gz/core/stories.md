## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_6: contact
* master_contact
    - utter_master_contact

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_7: degree
* master_degree
    - utter_master_degree

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_19: thank
* thank
    - utter_thank

## story_14: program_content
* master_program_content
    - utter_master_program_content

## story_9: electives
* master_electives
    - utter_master_electives

## story_1: bye
* bye
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_7: degree
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_6: contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_contact
    - utter_master_contact

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_9: electives
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_electives
    - utter_master_electives

## story_4: application_period
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_9: electives
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives

## story_4: application_period
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_application_period
    - utter_master_application_period

## story_6: contact
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_contact
    - utter_master_contact

## story_9: electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_electives
    - utter_master_electives

## story_18: tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_4: application_period
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* bye
    - utter_bye

## story_14: program_content
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_19: thank
* master_tuition_fees
    - utter_master_tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* thank
    - utter_thank

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_19: thank
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* thank
    - utter_thank

## story_7: degree
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_22: degree + application_period + duration + location + bye
* master_electives
    - utter_master_electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_application_period
    - utter_master_application_period
* master_electives
    - utter_master_electives

## story_1: bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_tuition_fees
    - utter_master_tuition_fees

## story_9: electives
* bye
    - utter_bye
* master_electives
    - utter_master_electives

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* thank
    - utter_thank

## story_22: degree + application_period + duration + location + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_24: starting_date + semester_content + thank + good_deny + bye
* thank
    - utter_thank
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* master_electives
    - utter_master_electives
* master_program_content
    - utter_master_program_content

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_19: thank
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank

## story_1: bye
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_7: degree
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_10: further_qualification
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_6: contact
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_19: thank
* master_degree
    - utter_master_degree
* thank
    - utter_thank

## story_9: electives
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives

## story_14: program_content
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_1: bye
* master_degree
    - utter_master_degree
* bye
    - utter_bye

## story_7: degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_6: contact
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact

## story_10: further_qualification
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* master_application_period
    - utter_master_application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_7: degree
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_degree
    - utter_master_degree

## story_1: bye
* master_tuition_fees
    - utter_master_tuition_fees
* bye
    - utter_bye

## story_18: tuition_fees
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_20: greet + program_content + language + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_19: thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_7: degree
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_7: degree
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_6: contact
* thank
    - utter_thank
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_19: thank
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* thank
    - utter_thank

## story_10: further_qualification
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_18: tuition_fees
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_22: degree + application_period + duration + location + bye
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_18: tuition_fees
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_10: further_qualification
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_4: application_period
* thank
    - utter_thank
* master_application_period
    - utter_master_application_period

## story_6: contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_contact
    - utter_master_contact

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_7: degree
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_14: program_content
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_program_content
    - utter_master_program_content

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_6: contact
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_contact
    - utter_master_contact

## story_6: contact
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* master_program_content
    - utter_master_program_content

## story_19: thank
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_4: application_period
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees
* master_application_period
    - utter_master_application_period

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* thank
    - utter_thank

## story_14: program_content
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_20: greet + program_content + language + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_1: bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_18: tuition_fees
* master_program_content
    - utter_master_program_content
* master_tuition_fees
    - utter_master_tuition_fees

## story_14: program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_7: degree
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree

## story_7: degree
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_9: electives
* master_program_content
    - utter_master_program_content
* master_electives
    - utter_master_electives
* master_electives
    - utter_master_electives

## story_7: degree
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_electives
    - utter_master_electives

## story_19: thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* thank
    - utter_thank

## story_14: program_content
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_4: application_period
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_19: thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* thank
    - utter_thank

## story_24: starting_date + semester_content + thank + good_deny + bye
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_electives
    - utter_master_electives

## story_9: electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_electives
    - utter_master_electives

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_6: contact
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact

## story_4: application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_19: thank
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* bye
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_electives
    - utter_master_electives

## story_7: degree
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_14: program_content
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_7: degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree

## story_20: greet + program_content + language + thank + good_deny + bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_7: degree
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_6: contact
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact

## story_1: bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_10: further_qualification
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_22: degree + application_period + duration + location + bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* master_program_content
    - utter_master_program_content
* master_application_period
    - utter_master_application_period

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_9: electives
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_electives
    - utter_master_electives

## story_9: electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_electives
    - utter_master_electives

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_4: application_period
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_19: thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* thank
    - utter_thank

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* bye
    - utter_bye

## story_7: degree
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree

## story_18: tuition_fees
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_tuition_fees
    - utter_master_tuition_fees

## story_22: degree + application_period + duration + location + bye
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_6: contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_9: electives
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_electives
    - utter_master_electives

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_18: tuition_fees
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_1: bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* bye
    - utter_bye

## story_1: bye
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_10: further_qualification
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_9: electives
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives

## story_22: degree + application_period + duration + location + bye
* thank
    - utter_thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_18: tuition_fees
* master_contact
    - utter_master_contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_1: bye
* master_application_period
    - utter_master_application_period
* master_program_content
    - utter_master_program_content
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

