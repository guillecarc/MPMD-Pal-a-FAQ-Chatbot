## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_18: tuition_fees
* master_tuition_fees
    - utter_master_tuition_fees

## story_19: thank
* thank
    - utter_thank

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* greet
    - utter_greet

## story_15: scholarships
* master_scholarships
    - utter_master_scholarships

## story_17: starting_date
* master_start
    - utter_master_start

## story_9: electives
* master_electives
    - utter_master_electives

## story_11: how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_5: career_opportunities
* master_career_opportunities
    - utter_master_career_opportunities

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_1: bye
* bye
    - utter_bye

## story_13: location
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_6: contact
* master_contact
    - utter_master_contact

## story_29: greet + program_content + semester_content + electives + start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_7: degree
* master_degree
    - utter_master_degree

## story_12: language
* master_language
    - utter_master_language

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_13: location
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_location
    - utter_master_location

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_1: bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_13: location
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_location
    - utter_master_location

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_start
    - utter_master_start

## story_13: location
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_13: location
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language

## story_17: starting_date
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_start
    - utter_master_start

## story_3: admission_requirements
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_7: degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* greet
    - utter_greet

## story_15: scholarships
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_scholarships
    - utter_master_scholarships

## story_18: tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_tuition_fees
    - utter_master_tuition_fees

## story_29: greet + program_content + semester_content + electives + start
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_18: tuition_fees
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_tuition_fees
    - utter_master_tuition_fees

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_tuition_fees
    - utter_master_tuition_fees

## story_12: language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_29: greet + program_content + semester_content + electives + start
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_15: scholarships
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_scholarships
    - utter_master_scholarships

## story_11: how_to_apply
* master_start
    - utter_master_start
* master_how_to_apply
    - utter_master_how_to_apply

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* thank
    - utter_thank

## story_5: career_opportunities
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_career_opportunities
    - utter_master_career_opportunities

## story_12: language
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_1: bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_7: degree
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_6: contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_contact
    - utter_master_contact

## story_5: career_opportunities
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_career_opportunities
    - utter_master_career_opportunities

## story_1: bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* bye
    - utter_bye

## story_9: electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_electives
    - utter_master_electives

## story_1: bye
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* bye
    - utter_bye

## story_2: greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* greet
    - utter_greet

## story_9: electives
* master_location
    - utter_master_location
* master_electives
    - utter_master_electives

## story_19: thank
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_5: career_opportunities
* master_electives
    - utter_master_electives
* master_career_opportunities
    - utter_master_career_opportunities

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet

## story_29: greet + program_content + semester_content + electives + start
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_7: degree
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_1: bye
* master_tuition_fees
    - utter_master_tuition_fees
* bye
    - utter_bye

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_contact
    - utter_master_contact

## story_19: thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* thank
    - utter_thank

## story_17: starting_date
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_start
    - utter_master_start

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_18: tuition_fees
* thank
    - utter_thank
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_15: scholarships
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_scholarships
    - utter_master_scholarships

## story_10: further_qualification
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_how_to_apply
    - utter_master_how_to_apply

## story_17: starting_date
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_18: tuition_fees
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees

## story_2: greet
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* greet
    - utter_greet

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_5: career_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_career_opportunities
    - utter_master_career_opportunities

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_15: scholarships
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* master_scholarships
    - utter_master_scholarships

## story_13: location
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_17: starting_date
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_start
    - utter_master_start

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_15: scholarships
* master_location
    - utter_master_location
* master_scholarships
    - utter_master_scholarships

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_6: contact
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_contact
    - utter_master_contact

## story_9: electives
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_electives
    - utter_master_electives

## story_5: career_opportunities
* master_degree
    - utter_master_degree
* master_career_opportunities
    - utter_master_career_opportunities

## story_6: contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_contact
    - utter_master_contact

## story_11: how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_7: degree
* master_start
    - utter_master_start
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree

## story_5: career_opportunities
* master_start
    - utter_master_start
* master_career_opportunities
    - utter_master_career_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_5: career_opportunities
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* master_career_opportunities
    - utter_master_career_opportunities

## story_17: starting_date
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_start
    - utter_master_start

## story_3: admission_requirements
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_18: tuition_fees
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_15: scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_scholarships
    - utter_master_scholarships

## story_15: scholarships
* bye
    - utter_bye
* master_scholarships
    - utter_master_scholarships

## story_19: thank
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_6: contact
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_contact
    - utter_master_contact

## story_7: degree
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree

## story_19: thank
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* thank
    - utter_thank

## story_12: language
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_language
    - utter_master_language

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_6: contact
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_contact
    - utter_master_contact

## story_2: greet
* master_tuition_fees
    - utter_master_tuition_fees
* greet
    - utter_greet

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_5: career_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_career_opportunities
    - utter_master_career_opportunities

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_1: bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* bye
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_22: degree + application_period + duration + location + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_18: tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_tuition_fees
    - utter_master_tuition_fees

## story_15: scholarships
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_3: admission_requirements
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_admission_requirements
    - utter_master_admission_requirements

## story_2: greet
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* greet
    - utter_greet

## story_10: further_qualification
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_17: starting_date
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* master_start
    - utter_master_start

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language

## story_19: thank
* master_electives
    - utter_master_electives
* thank
    - utter_thank

## story_6: contact
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_6: contact
* master_tuition_fees
    - utter_master_tuition_fees
* thank
    - utter_thank
* master_contact
    - utter_master_contact

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_11: how_to_apply
* master_tuition_fees
    - utter_master_tuition_fees
* master_degree
    - utter_master_degree
* master_how_to_apply
    - utter_master_how_to_apply

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_electives
    - utter_master_electives
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_6: contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_11: how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_13: location
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location

## story_7: degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_15: scholarships
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_scholarships
    - utter_master_scholarships

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_15: scholarships
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_scholarships
    - utter_master_scholarships

## story_24: starting_date + semester_content + thank + good_deny + bye
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply

## story_10: further_qualification
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_17: starting_date
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* master_start
    - utter_master_start

## story_1: bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* bye
    - utter_bye

## story_3: admission_requirements
* master_electives
    - utter_master_electives
* master_admission_requirements
    - utter_master_admission_requirements

## story_1: bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* bye
    - utter_bye

## story_1: bye
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_7: degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_degree
    - utter_master_degree

## story_15: scholarships
* thank
    - utter_thank
* master_scholarships
    - utter_master_scholarships

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_17: starting_date
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* master_start
    - utter_master_start

## story_12: language
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language

## story_2: greet
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet

## story_12: language
* master_start
    - utter_master_start
* master_language
    - utter_master_language

## story_29: greet + program_content + semester_content + electives + start
* master_admission_requirements
    - utter_master_admission_requirements
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_scholarships
    - utter_master_scholarships
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_9: electives
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_location
    - utter_master_location
* master_electives
    - utter_master_electives

## story_17: starting_date
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_start
    - utter_master_start

## story_3: admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_admission_requirements
    - utter_master_admission_requirements

## story_7: degree
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_degree
    - utter_master_degree

## story_18: tuition_fees
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* master_contact
    - utter_master_contact
* greet
    - utter_greet

## story_13: location
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_location
    - utter_master_location

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_7: degree
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree

## story_18: tuition_fees
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* master_tuition_fees
    - utter_master_tuition_fees

## story_24: starting_date + semester_content + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_location
    - utter_master_location
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_admission_requirements
    - utter_master_admission_requirements

## story_17: starting_date
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_9: electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_electives
    - utter_master_electives

## story_21: greet + tuition_fees + scholarship + thank + good_deny + bye
* master_start
    - utter_master_start
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_15: scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_electives
    - utter_master_electives
* master_scholarships
    - utter_master_scholarships

## story_13: location
* master_start
    - utter_master_start
* master_how_to_apply
    - utter_master_how_to_apply
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_29: greet + program_content + semester_content + electives + start
* master_admission_requirements
    - utter_master_admission_requirements
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_6: contact
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_contact
    - utter_master_contact

## story_2: greet
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start
* greet
    - utter_greet

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_15: scholarships
* master_start
    - utter_master_start
* master_scholarships
    - utter_master_scholarships

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_19: thank
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_9: electives
* master_scholarships
    - utter_master_scholarships
* master_language
    - utter_master_language
* master_electives
    - utter_master_electives

## story_5: career_opportunities
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_career_opportunities
    - utter_master_career_opportunities

## story_18: tuition_fees
* master_scholarships
    - utter_master_scholarships
* greet
    - utter_greet
* master_tuition_fees
    - utter_master_tuition_fees
* master_scholarships
    - utter_master_scholarships
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_tuition_fees
    - utter_master_tuition_fees

## story_6: contact
* master_language
    - utter_master_language
* master_contact
    - utter_master_contact

## story_17: starting_date
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_start
    - utter_master_start

## story_5: career_opportunities
* master_start
    - utter_master_start
* master_how_to_apply
    - utter_master_how_to_apply
* master_career_opportunities
    - utter_master_career_opportunities

## story_7: degree
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_degree
    - utter_master_degree

## story_29: greet + program_content + semester_content + electives + start
* master_start
    - utter_master_start
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives
* master_start
    - utter_master_start

## story_3: admission_requirements
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_25: program_content + further_qualification + career_opportunities + semester_content + electives
* master_location
    - utter_master_location
* master_program_content
    - utter_master_program_content
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_career_opportunities
    - utter_master_career_opportunities
* master_semester_content
    - utter_master_semester_one_subjects
    - utter_master_semester_three_subjects
    - utter_master_semester_two_subjects
* master_electives
    - utter_master_electives

