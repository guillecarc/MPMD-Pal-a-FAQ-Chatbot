## story_10: further_qualification
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_12: language
* master_language
    - utter_master_language

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_19: thank
* thank
    - utter_thank

## story_4: application_period
* master_application_period
    - utter_master_application_period

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_2: greet
* greet
    - utter_greet

## story_13: location
* master_location
    - utter_master_location

## story_11: how_to_apply
* master_how_to_apply
    - utter_master_how_to_apply

## story_8: duration
* master_duration
    - utter_master_duration

## story_1: bye
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_10: further_qualification
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_19: thank
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank

## story_11: how_to_apply
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_how_to_apply
    - utter_master_how_to_apply

## story_19: thank
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_12: language
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_3: admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_admission_requirements
    - utter_master_admission_requirements

## story_20: greet + program_content + language + thank + good_deny + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* bye
    - utter_bye
* bye
    - utter_bye

## story_8: duration
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_location
    - utter_master_location
* master_duration
    - utter_master_duration

## story_2: greet
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_language
    - utter_master_language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_8: duration
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* greet
    - utter_greet

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration
* master_admission_requirements
    - utter_master_admission_requirements

## story_8: duration
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_duration
    - utter_master_duration

## story_19: thank
* master_application_period
    - utter_master_application_period
* thank
    - utter_thank

## story_8: duration
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_duration
    - utter_master_duration

## story_12: language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language

## story_2: greet
* bye
    - utter_bye
* greet
    - utter_greet

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_19: thank
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* thank
    - utter_thank

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* bye
    - utter_bye

## story_11: how_to_apply
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_13: location
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_13: location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_location
    - utter_master_location

## story_4: application_period
* master_location
    - utter_master_location
* thank
    - utter_thank
* master_application_period
    - utter_master_application_period

## story_22: degree + application_period + duration + location + bye
* master_duration
    - utter_master_duration
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_8: duration
* greet
    - utter_greet
* master_duration
    - utter_master_duration

## story_1: bye
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_12: language
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language

## story_8: duration
* bye
    - utter_bye
* master_duration
    - utter_master_duration

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_22: degree + application_period + duration + location + bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_11: how_to_apply
* master_duration
    - utter_master_duration
* master_how_to_apply
    - utter_master_how_to_apply

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_13: location
* master_language
    - utter_master_language
* master_location
    - utter_master_location

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* bye
    - utter_bye

## story_4: application_period
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_10: further_qualification
* master_how_to_apply
    - utter_master_how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements

## story_13: location
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_8: duration
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_duration
    - utter_master_duration

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_how_to_apply
    - utter_master_how_to_apply

## story_1: bye
* master_application_period
    - utter_master_application_period
* bye
    - utter_bye

## story_4: application_period
* thank
    - utter_thank
* master_application_period
    - utter_master_application_period

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* thank
    - utter_thank
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_2: greet
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_19: thank
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* thank
    - utter_thank

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_10: further_qualification
* greet
    - utter_greet
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_location
    - utter_master_location
* master_application_period
    - utter_master_application_period

## story_1: bye
* master_language
    - utter_master_language
* bye
    - utter_bye

## story_12: language
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_19: thank
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* thank
    - utter_thank

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_13: location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_4: application_period
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_application_period
    - utter_master_application_period

## story_3: admission_requirements
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_19: thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* thank
    - utter_thank

## story_13: location
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_10: further_qualification
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_12: language
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language

## story_22: degree + application_period + duration + location + bye
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_12: language
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language

## story_10: further_qualification
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye

## story_2: greet
* master_location
    - utter_master_location
* greet
    - utter_greet

## story_3: admission_requirements
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_8: duration
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_11: how_to_apply
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_how_to_apply
    - utter_master_how_to_apply

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_3: admission_requirements
* bye
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_19: thank
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* thank
    - utter_thank

## story_3: admission_requirements
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_admission_requirements
    - utter_master_admission_requirements

## story_3: admission_requirements
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_22: degree + application_period + duration + location + bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_20: greet + program_content + language + thank + good_deny + bye
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_11: how_to_apply
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply

## story_13: location
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_location
    - utter_master_location

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* greet
    - utter_greet

## story_13: location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_11: how_to_apply
* master_location
    - utter_master_location
* thank
    - utter_thank
* master_how_to_apply
    - utter_master_how_to_apply

## story_19: thank
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* thank
    - utter_thank

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_1: bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* bye
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_12: language
* master_how_to_apply
    - utter_master_how_to_apply
* master_language
    - utter_master_language

## story_11: how_to_apply
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_4: application_period
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_4: application_period
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_8: duration
* master_how_to_apply
    - utter_master_how_to_apply
* master_duration
    - utter_master_duration
* master_duration
    - utter_master_duration

## story_4: application_period
* master_language
    - utter_master_language
* master_application_period
    - utter_master_application_period

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_8: duration
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_duration
    - utter_master_duration

## story_13: location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_location
    - utter_master_location

## story_11: how_to_apply
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* master_location
    - utter_master_location

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_8: duration
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_duration
    - utter_master_duration

## story_8: duration
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language
* master_duration
    - utter_master_duration

## story_27: language + admission_requirements + application_period + career_opportunities + how_to_apply + contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_3: admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements

## story_2: greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet

## story_13: location
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_location
    - utter_master_location

## story_19: thank
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* thank
    - utter_thank

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_location
    - utter_master_location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_8: duration
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_duration
    - utter_master_duration

## story_4: application_period
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_19: thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank

## story_11: how_to_apply
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply

## story_10: further_qualification
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_22: degree + application_period + duration + location + bye
* master_application_period
    - utter_master_application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_19: thank
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank
* thank
    - utter_thank

## story_2: greet
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet

## story_4: application_period
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_20: greet + program_content + language + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_19: thank
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* thank
    - utter_thank

## story_22: degree + application_period + duration + location + bye
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_3: admission_requirements
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements

## story_1: bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_10: further_qualification
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_22: degree + application_period + duration + location + bye
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_20: greet + program_content + language + thank + good_deny + bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_2: greet
* master_how_to_apply
    - utter_master_how_to_apply
* greet
    - utter_greet

## story_20: greet + program_content + language + thank + good_deny + bye
* master_admission_requirements
    - utter_master_admission_requirements
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_22: degree + application_period + duration + location + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_8: duration
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* master_duration
    - utter_master_duration

## story_8: duration
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_duration
    - utter_master_duration

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_10: further_qualification
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_2: greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet

## story_13: location
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_location
    - utter_master_location

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_1: bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_4: application_period
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_application_period
    - utter_master_application_period

## story_12: language
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location
* master_language
    - utter_master_language

## story_22: degree + application_period + duration + location + bye
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_3: admission_requirements
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_admission_requirements
    - utter_master_admission_requirements

## story_8: duration
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_duration
    - utter_master_duration

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_12: language
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* thank
    - utter_thank
* master_language
    - utter_master_language

## story_20: greet + program_content + language + thank + good_deny + bye
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye

## story_28: degree + duration + qualification_opportunities + application_period + location
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

## story_1: bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_how_to_apply
    - utter_master_how_to_apply
* bye
    - utter_bye

## story_1: bye
* greet
    - utter_greet
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* bye
    - utter_bye

## story_10: further_qualification
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities

## story_8: duration
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* greet
    - utter_greet
* master_program_content
    - utter_master_program_content
* master_language
    - utter_master_language
* thank
    - utter_thank
* good_deny
    - utter_bye
* master_duration
    - utter_master_duration

## story_22: degree + application_period + duration + location + bye
* master_location
    - utter_master_location
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye
* master_degree
    - utter_master_degree
* master_application_period
    - utter_master_application_period
* master_duration
    - utter_master_duration
* master_location
    - utter_master_location
* bye
    - utter_bye

## story_19: thank
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* thank
    - utter_thank

## story_23: greet + admission_requirements + how_to_apply + contact + bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye
* greet
    - utter_greet
* master_admission_requirements
    - utter_master_admission_requirements
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* bye
    - utter_bye

## story_12: language
* master_admission_requirements
    - utter_master_admission_requirements
* master_language
    - utter_master_language
* master_admission_requirements
    - utter_master_admission_requirements
* master_application_period
    - utter_master_application_period
* master_career_opportunities
    - utter_master_career_opportunities
* master_how_to_apply
    - utter_master_how_to_apply
* master_contact
    - utter_master_contact
* master_language
    - utter_master_language

## story_1: bye
* greet
    - utter_greet
* master_how_to_apply
    - utter_master_how_to_apply
* master_admission_requirements
    - utter_master_admission_requirements
* bye
    - utter_bye

## story_19: thank
* master_admission_requirements
    - utter_master_admission_requirements
* greet
    - utter_greet
* thank
    - utter_thank

## story_28: degree + duration + qualification_opportunities + application_period + location
* master_location
    - utter_master_location
* master_degree
    - utter_master_degree
* master_duration
    - utter_master_duration
* master_further_qualification_opportunities
    - utter_master_further_qualification_opportunities
* master_application_period
    - utter_master_application_period
* master_location
    - utter_master_location

