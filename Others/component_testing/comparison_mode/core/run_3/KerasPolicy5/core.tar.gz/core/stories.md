## story_19: thank
* thank
    - utter_thank

## story_19: thank
* thank
    - utter_thank
* thank
    - utter_thank

## story_19: thank
* thank
    - utter_thank
* thank
    - utter_thank
* thank
    - utter_thank
* thank
    - utter_thank

## story_19: thank
* thank
    - utter_thank
* thank
    - utter_thank
* thank
    - utter_thank

